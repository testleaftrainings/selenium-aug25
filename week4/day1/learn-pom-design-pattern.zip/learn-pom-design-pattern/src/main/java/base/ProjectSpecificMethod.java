package base;

import java.time.Duration;

import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;

public class ProjectSpecificMethod {

//	protected static ChromeDriver driver;
	static ExtentReports extent;
	protected String testcaseName, testcaseDesc, author, category;
	protected static ExtentTest node;
	
	private static final ThreadLocal<RemoteWebDriver> rd = new ThreadLocal<RemoteWebDriver>();
//	private static final ThreadLocal<ExtentReports> extentReport = new ThreadLocal<ExtentReports>();
	private static final ThreadLocal<ExtentTest> testNode = new ThreadLocal<ExtentTest>();
	
	
	/**--Extent Report--**/
	
	public void setNode(ExtentTest node) {
		testNode.set(node);
	}
	
	public ExtentTest getNode() {
		return testNode.get();
	}
	
	
	@BeforeSuite
	public void startReport() {
		ExtentHtmlReporter reporter = new ExtentHtmlReporter("./report/result.html");
//		reporter.setAppendExisting(true);
		extent = new ExtentReports();
		extent.attachReporter(reporter);
	}
	
	@BeforeClass
	public void startTestcase() {
		ExtentTest test = extent.createTest(testcaseName, testcaseDesc);
		test.assignAuthor(author);
		test.assignCategory(category);
//		node = test.createNode(testcaseName);
		setNode(test.createNode(testcaseName));
	}
	
	
	
	/**--Driver--**/
	
	public void setDriver(RemoteWebDriver driver) {
		rd.set(driver);
	}
	
	public RemoteWebDriver getDriver() {
		return rd.get();
	}

	@BeforeMethod
	public void preCondition() {
		System.out.println("BeforeMethod");
		ChromeOptions options = new ChromeOptions();
		options.addArguments("guest");
//		driver = new ChromeDriver(options);
		setDriver(new ChromeDriver(options));
		getNode().info("ChromeDriver launched successfully");
		getDriver().manage().window().maximize();
		getDriver().manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		getDriver().get("http://leaftaps.com/opentaps/");
	}
	
	
	@AfterMethod
	public void postCondition() {
		System.out.println("AfterMethod");
		getDriver().quit();
	}
	
	@AfterSuite
	public void endResult() {
		extent.flush();
	}
	
}

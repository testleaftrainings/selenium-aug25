package leaftaps.pages;

public class FindLeadsPage {

	
	public void enterPhoneNumber() {
		
	}
	
	public void enterFirstName() {
		
	}
	
	public void clickFindLeadsButton() {
		
	}
	
	public void clickFirstLeadId() {
		
	}
	
}

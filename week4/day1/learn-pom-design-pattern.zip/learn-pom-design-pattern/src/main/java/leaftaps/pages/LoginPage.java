package leaftaps.pages;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.WebDriverException;

import com.aventstack.extentreports.MediaEntityBuilder;

import base.ProjectSpecificMethod;

public class LoginPage extends ProjectSpecificMethod{

	public LoginPage enterUsername() throws WebDriverException, IOException {
		try {
			getDriver().findElement(By.id("username")).sendKeys("demosalesmanager");
			String screenshotAs = getDriver().getScreenshotAs(OutputType.BASE64);
			getNode().pass("Username entered successfull", MediaEntityBuilder.createScreenCaptureFromBase64String(screenshotAs).build());
		}catch(Exception e) {
			getNode().fail("failed to enter the username "+e, MediaEntityBuilder.createScreenCaptureFromBase64String(getDriver().getScreenshotAs(OutputType.BASE64)).build() );
		}
	return this;
	}
	
	public LoginPage enterPassword() throws WebDriverException, IOException {
		try {
			getDriver().findElement(By.id("password")).sendKeys("crmsfa");
			getNode().pass("Password entered successfully", MediaEntityBuilder.createScreenCaptureFromBase64String(getDriver().getScreenshotAs(OutputType.BASE64)).build());
		}catch (Exception e) {
			getNode().fail("Failed to enter the password "+e,MediaEntityBuilder.createScreenCaptureFromBase64String(getDriver().getScreenshotAs(OutputType.BASE64)).build());
		}
	return this;
	}
	
	public WelcomePage clickLoginButton() throws WebDriverException, IOException {
		try {
			getDriver().findElement(By.className("decorativeSubmit")).click();
			getNode().pass("Login Button clicked ", MediaEntityBuilder.createScreenCaptureFromBase64String(getDriver().getScreenshotAs(OutputType.BASE64)).build());
		}catch (Exception e) {
			getNode().fail("Failed to click login button due to "+e , MediaEntityBuilder.createScreenCaptureFromBase64String(getDriver().getScreenshotAs(OutputType.BASE64)).build());
		}
	return new WelcomePage();
	}
	
}

package leaftaps.pages;

public class AccountsPage {

	
	public void enterAccountName() {
		
	}
	
	public void clickCreateAccountButton() {
		
	}
	
}

package leaftaps.pages;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.WebDriverException;

import com.aventstack.extentreports.MediaEntityBuilder;

import base.ProjectSpecificMethod;

public class WelcomePage extends ProjectSpecificMethod{

	
	public HomePage clickCrmsfa() throws WebDriverException, IOException {
		try {
			getDriver().findElement(By.linkText("CRM/SFA")).click();
			getNode().pass("CRMSFA link clicked successfully", MediaEntityBuilder.createScreenCaptureFromBase64String(getDriver().getScreenshotAs(OutputType.BASE64)).build());
		}catch (Exception e) {
			getNode().fail("Failed to click CRMSFA link "+e, MediaEntityBuilder.createScreenCaptureFromBase64String(getDriver().getScreenshotAs(OutputType.BASE64)).build());
		}
	return new HomePage();
	}
	
	
	public LoginPage clickLogoutButton() {
		getDriver().findElement(By.className("decorativeSubmit")).click();
	return new LoginPage();
	}
	
}

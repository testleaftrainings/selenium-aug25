package leaftaps.pages;

import org.openqa.selenium.By;
import org.testng.Assert;

import base.ProjectSpecificMethod;

public class ViewLeadPage extends ProjectSpecificMethod{

	public ViewLeadPage retriveCompanyName() {
		String text = getDriver().findElement(By.id("viewLead_companyName_sp")).getText();
		System.out.println("CompanyName is "+text);
	return this;
	}
	
	public ViewLeadPage retriveLeadId() {
		String text = getDriver().findElement(By.id("viewLead_companyName_sp")).getText().replaceAll("[^0-9]", "");
		int leadId = Integer.parseInt(text);
		Assert.assertTrue(leadId>0,"Lead id is not generated");
	return this;
	}
	
	public void clickEditButton() {
		
	}
	
	public void clickDuplicateButton() {
		
	}
	
	public void clickDeleteButton() {
		
	}
	
	
}

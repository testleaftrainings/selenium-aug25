package leaftaps.testcases;

import java.io.IOException;

import org.openqa.selenium.WebDriverException;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.ProjectSpecificMethod;
import leaftaps.pages.LoginPage;

public class TC001_CreateLead extends ProjectSpecificMethod{

	@Test
	public void runCreateLead() throws WebDriverException, IOException {
		
//		LoginPage lp = new LoginPage();
		new LoginPage().enterUsername()
		.enterPassword()
		.clickLoginButton()
		.clickCrmsfa()
		.clickLeadsTab()
		.clickCreateLeadLink()
		.enterCompanyName()
		.enterFirstName()
		.enterLastName()
		.enterPhoneNumber()
		.clickSubmitButton()
		.retriveCompanyName()
		.retriveLeadId();
	}
	
	@BeforeTest
	public void setTestcaseInfo() {
		testcaseName = "Create Lead";
		testcaseDesc = "Create Lead for Leaftaps application with valid testdata in only mandatory fields";
		author = "Gokul";
		category = "Regression";
	}
	
}

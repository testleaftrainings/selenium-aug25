package leaftaps.pages;

import org.openqa.selenium.By;

import base.ProjectSpecificMethod;

public class CreateLeadPage extends ProjectSpecificMethod{

	public CreateLeadPage enterCompanyName() {
		getDriver().findElement(By.id("createLeadForm_companyName")).sendKeys("Qeagle");		
	return this;
	}
	
	public CreateLeadPage enterFirstName() {
		getDriver().findElement(By.id("createLeadForm_firstName")).sendKeys("Gokul");
	return this;
	}
	
	public CreateLeadPage enterLastName() {
		getDriver().findElement(By.id("createLeadForm_lastName")).sendKeys("Sekar");
	return this;
	}
	
	public CreateLeadPage enterPhoneNumber() {
		getDriver().findElement(By.id("createLeadForm_primaryPhoneNumber")).sendKeys("99");
	return this;
	}
	
	public ViewLeadPage clickSubmitButton() {
		getDriver().findElement(By.name("submitButton")).click();
	return new ViewLeadPage();
	}
	
}

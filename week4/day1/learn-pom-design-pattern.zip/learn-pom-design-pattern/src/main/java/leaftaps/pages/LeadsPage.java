package leaftaps.pages;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.WebDriverException;

import com.aventstack.extentreports.MediaEntityBuilder;

import base.ProjectSpecificMethod;

public class LeadsPage extends ProjectSpecificMethod{

	public CreateLeadPage clickCreateLeadLink() {
		getDriver().findElement(By.linkText("Create Lead")).click();
	return new CreateLeadPage();
	}
	
	public FindLeadsPage clickFindLeadLink() throws WebDriverException, IOException {
		try {
			getDriver().findElement(By.linkText("Find Leads")).click();
			getNode().pass("Find lead link clicked successsfully", MediaEntityBuilder.createScreenCaptureFromBase64String(getDriver().getScreenshotAs(OutputType.BASE64)).build());
		}catch (Exception e) {
			getNode().pass("Failed to click the find lead link "+e, MediaEntityBuilder.createScreenCaptureFromBase64String(getDriver().getScreenshotAs(OutputType.BASE64)).build());
		}
	return new FindLeadsPage();
	}
	
	public MergeLeadPage clickMergeLeadLink() {
		
	return new MergeLeadPage();
	}
	
	
}

package leaftaps.testcases;

import java.io.IOException;

import org.openqa.selenium.WebDriverException;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.ProjectSpecificMethod;
import leaftaps.pages.LoginPage;

public class TC002_EditLead extends ProjectSpecificMethod{

	
	@Test
	public void runEditLead() throws WebDriverException, IOException {
		
//		LoginPage lp = new LoginPage();
		new LoginPage().enterUsername()
		.enterPassword()
		.clickLoginButton()
		.clickCrmsfa()
		.clickLeadsTab()
		.clickFindLeadLink()
		.enterPhoneNumber();
	}
	
	@BeforeTest
	public void setTestcaseInfo() {
		testcaseName = "Edit Lead";
		testcaseDesc = "Edit the existing lead created by using phone number";
		author = "Gokul";
		category = "Regression";
	}
	
	
}

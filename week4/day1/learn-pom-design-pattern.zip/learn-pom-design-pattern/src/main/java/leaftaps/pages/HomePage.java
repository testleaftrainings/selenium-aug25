package leaftaps.pages;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.WebDriverException;

import com.aventstack.extentreports.MediaEntityBuilder;

import base.ProjectSpecificMethod;

public class HomePage extends ProjectSpecificMethod{

	public LeadsPage clickLeadsTab() throws WebDriverException, IOException {
		try {
			getDriver().findElement(By.linkText("Leads")).click();
			getNode().pass("Leads tab clicked successfully", MediaEntityBuilder.createScreenCaptureFromBase64String(getDriver().getScreenshotAs(OutputType.BASE64)).build());
		}catch (Exception e) {
			getNode().fail("Failed to click the leads tab "+e, MediaEntityBuilder.createScreenCaptureFromBase64String(getDriver().getScreenshotAs(OutputType.BASE64)).build());
		}
	return new LeadsPage();
	}
	
	public AccountsPage clickAccountsTab() {
		getDriver().findElement(By.linkText("Accounts")).click();
	return new AccountsPage();
	}
	
	public void clickOpportunitiesTab() {
		
	}
	
	
}

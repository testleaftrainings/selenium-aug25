package leaftaps.pages;

public class MergeLeadPage {

	public void clickFromLead() {
		
	}
	
	public void clickToLead() {
		
	}
	
	
}
